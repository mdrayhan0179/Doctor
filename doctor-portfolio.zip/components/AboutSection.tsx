import React from 'react';
import { FileText, Award, User, Heart, Activity } from 'lucide-react';
import { EXPERTISE_TAGS } from '../constants';

const AboutSection: React.FC = () => {
    return (
        <section id="about" className="relative py-24 px-4 bg-slate-800/30">
            <div className="max-w-6xl mx-auto z-10 relative">
                <div className="text-center mb-16">
                    <h2 className="text-3xl md:text-5xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent mb-4">
                        About Dr. Mollah
                    </h2>
                    <div className="h-1 w-24 bg-blue-500 mx-auto rounded-full opacity-80"></div>
                </div>

                <div className="grid md:grid-cols-2 gap-12 lg:gap-16 items-center">
                    <div className="space-y-6 text-lg text-slate-300 leading-relaxed">
                        <p>
                            <strong className="text-white">Dr. Mohibulla Mollah</strong> is a distinguished Consultant Physician in Internal Medicine, serving the community of Howrah, West Bengal. He is renowned for his diagnostic acumen and compassionate approach to patient care.
                        </p>

                        <div className="p-6 bg-blue-500/5 border-l-4 border-blue-500 rounded-r-xl my-6">
                            <p className="text-slate-200 italic font-medium">
                                "Having treated over <span className="text-blue-400 font-bold">30,000 patients</span>, my mission is to provide holistic, patient-centered medical care that addresses the root cause of illness, not just the symptoms."
                            </p>
                        </div>

                        <p>
                            Dr. Mollah combines extensive clinical experience with the latest medical guidelines to manage complex multi-system disorders, ensuring the highest standard of healthcare delivery for every individual.
                        </p>

                        <div className="pt-6">
                            <h3 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
                                <FileText className="w-5 h-5 text-blue-400" /> Areas of Expertise
                            </h3>
                            <div className="flex flex-wrap gap-2">
                                {EXPERTISE_TAGS.map((tag) => (
                                    <span key={tag} className="bg-slate-900 text-blue-300 px-4 py-2 rounded-full text-sm border border-blue-500/20 shadow-sm hover:bg-blue-500/10 transition-colors cursor-default">
                                        {tag}
                                    </span>
                                ))}
                            </div>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="bg-slate-900/60 backdrop-blur-sm p-6 rounded-2xl border border-white/5 hover:border-blue-500/40 transition-all group hover:-translate-y-1 duration-300">
                            <Award className="w-10 h-10 text-blue-500 mb-4 group-hover:scale-110 transition-transform" />
                            <div className="font-bold text-white text-lg">Specialist</div>
                            <div className="text-slate-400 text-sm">Internal Medicine</div>
                        </div>
                        <div className="bg-slate-900/60 backdrop-blur-sm p-6 rounded-2xl border border-blue-500/20 hover:border-blue-500/60 transition-all group hover:-translate-y-1 duration-300 shadow-lg shadow-blue-900/10">
                            <User className="w-10 h-10 text-cyan-400 mb-4 group-hover:scale-110 transition-transform" />
                            <div className="font-bold text-white text-lg">30,000+</div>
                            <div className="text-slate-400 text-sm">Patients Recovered</div>
                        </div>
                        <div className="bg-slate-900/60 backdrop-blur-sm p-6 rounded-2xl border border-white/5 hover:border-blue-500/40 transition-all group hover:-translate-y-1 duration-300">
                            <Heart className="w-10 h-10 text-rose-500 mb-4 group-hover:scale-110 transition-transform" />
                            <div className="font-bold text-white text-lg">Holistic</div>
                            <div className="text-slate-400 text-sm">Patient-First Approach</div>
                        </div>
                        <div className="bg-slate-900/60 backdrop-blur-sm p-6 rounded-2xl border border-white/5 hover:border-blue-500/40 transition-all group hover:-translate-y-1 duration-300">
                            <Activity className="w-10 h-10 text-green-500 mb-4 group-hover:scale-110 transition-transform" />
                            <div className="font-bold text-white text-lg">Comprehensive</div>
                            <div className="text-slate-400 text-sm">Acute & Chronic Care</div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default AboutSection;
