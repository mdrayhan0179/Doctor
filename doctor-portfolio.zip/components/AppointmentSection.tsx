import React from 'react';
import { FormData, Appointment } from '../types';
import { Calendar, Clock, ChevronDown, Check } from 'lucide-react';

interface AppointmentSectionProps {
    formData: FormData;
    setFormData: React.Dispatch<React.SetStateAction<FormData>>;
    handleSubmit: () => void;
    showSuccess: boolean;
    appointments: Appointment[];
}

const AppointmentSection: React.FC<AppointmentSectionProps> = ({ formData, setFormData, handleSubmit, showSuccess, appointments }) => {
    const inputClasses = "w-full bg-slate-900/50 border border-slate-700 rounded-xl px-5 py-4 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all text-white placeholder-slate-500 font-medium hover:border-slate-600";
    const labelClasses = "block text-sm font-semibold mb-2 text-slate-300 ml-1";

    return (
        <section id="appointments" className="relative py-24 px-4 bg-slate-800/30">
            <div className="max-w-4xl mx-auto z-10 relative">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-5xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent mb-4">
                        Book Your Consultation
                    </h2>
                    <p className="text-slate-400 text-lg">
                        Schedule a visit effortlessly. Your health is our priority.
                    </p>
                </div>

                {showSuccess && (
                    <div className="mb-8 bg-green-500/10 border border-green-500/50 text-green-400 p-4 rounded-xl flex items-center space-x-3 animate-fade-in shadow-lg shadow-green-900/20">
                        <div className="bg-green-500/20 p-2 rounded-full">
                            <Check className="w-5 h-5" />
                        </div>
                        <span className="font-medium">Appointment request sent successfully! Our team will contact you soon.</span>
                    </div>
                )}

                <div className="bg-slate-900/80 backdrop-blur-xl p-8 md:p-10 rounded-3xl border border-blue-500/20 shadow-2xl">
                    <div className="grid md:grid-cols-2 gap-6">
                        <div>
                            <label className={labelClasses}>Full Name</label>
                            <input type="text" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className={inputClasses} placeholder="e.g. Amit Roy" />
                        </div>
                        <div>
                            <label className={labelClasses}>Email Address</label>
                            <input type="email" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} className={inputClasses} placeholder="amit@example.com" />
                        </div>
                        <div className="md:col-span-2">
                            <label className={labelClasses}>Phone Number</label>
                            <div className="flex gap-3">
                                <div className="relative w-32 shrink-0">
                                    <select value={formData.countryCode} onChange={(e) => setFormData({ ...formData, countryCode: e.target.value })} className={`${inputClasses} appearance-none cursor-pointer pr-8`}>
                                        <option value="+91">🇮🇳 +91</option>
                                        <option value="+880">🇧🇩 +880</option>
                                        <option value="+1">🇺🇸 +1</option>
                                        <option value="+44">🇬🇧 +44</option>
                                        <option value="+971">🇦🇪 +971</option>
                                    </select>
                                    <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none">
                                        <ChevronDown className="w-4 h-4 text-slate-400" />
                                    </div>
                                </div>
                                <input type="tel" value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })} className={inputClasses} placeholder="98765 43210" />
                            </div>
                        </div>
                        <div>
                            <label className={labelClasses}>Preferred Date</label>
                            <input type="date" value={formData.date} onChange={(e) => setFormData({ ...formData, date: e.target.value })} className={`${inputClasses} [color-scheme:dark]`} />
                        </div>
                        <div>
                            <label className={labelClasses}>Preferred Time</label>
                            <input type="time" value={formData.time} onChange={(e) => setFormData({ ...formData, time: e.target.value })} className={`${inputClasses} [color-scheme:dark]`} />
                        </div>
                        <div className="md:col-span-2">
                            <label className={labelClasses}>Reason for Visit</label>
                            <textarea value={formData.reason} onChange={(e) => setFormData({ ...formData, reason: e.target.value })} rows={4} className={`${inputClasses} resize-none`} placeholder="Briefly describe your symptoms or reason for appointment..." />
                        </div>
                    </div>
                    <button onClick={handleSubmit} className="w-full mt-10 bg-gradient-to-r from-blue-600 to-cyan-600 text-white py-4 rounded-xl font-bold text-lg hover:from-blue-500 hover:to-cyan-500 transition-all transform hover:scale-[1.01] shadow-lg shadow-blue-500/25 active:scale-95 flex items-center justify-center gap-2">
                        Confirm Appointment Request <Check className="w-5 h-5" />
                    </button>
                </div>

                {appointments.length > 0 && (
                    <div className="mt-16 animate-fade-in">
                        <h3 className="text-2xl font-bold mb-6 text-white flex items-center gap-3">
                            <Calendar className="w-6 h-6 text-blue-400" />
                            Scheduled Visits
                        </h3>
                        <div className="grid gap-4 md:grid-cols-2">
                            {appointments.map((apt) => (
                                <div key={apt.id} className="bg-slate-800/60 backdrop-blur-md p-6 rounded-xl border-l-4 border-blue-500 shadow-lg">
                                    <div className="flex justify-between items-start mb-4">
                                        <div>
                                            <h4 className="font-bold text-lg text-white">{apt.name}</h4>
                                            <p className="text-sm text-blue-300">{apt.fullPhone}</p>
                                        </div>
                                        <span className="px-3 py-1 bg-yellow-500/10 text-yellow-400 border border-yellow-500/20 rounded-full text-xs font-medium uppercase tracking-wide">
                                            {apt.status}
                                        </span>
                                    </div>
                                    <div className="flex items-center gap-6 text-sm text-slate-400 border-t border-white/5 pt-4 mt-2">
                                        <span className="flex items-center gap-2"><Calendar className="w-4 h-4 text-slate-500" /> {apt.date}</span>
                                        <span className="flex items-center gap-2"><Clock className="w-4 h-4 text-slate-500" /> {apt.time}</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </section>
    );
};

export default AppointmentSection;
