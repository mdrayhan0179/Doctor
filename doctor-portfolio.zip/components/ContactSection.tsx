import React, { useState, useEffect } from 'react';
import { Phone, Mail, MapPin, Send, Check, AlertTriangle } from 'lucide-react';

// To make TypeScript happy with the EmailJS script loaded from CDN
declare global {
    interface Window {
        emailjs: {
            send: (serviceID: string, templateID: string, templateParams: Record<string, unknown>, publicKey: string) => Promise<{ status: number; text: string; }>;
        }
    }
}

const ContactSection: React.FC = () => {
    const [formData, setFormData] = useState({ name: '', email: '', message: '' });
    const [isSending, setIsSending] = useState(false);
    const [formStatus, setFormStatus] = useState<{ type: 'success' | 'error' | null; message: string }>({ type: null, message: '' });

    useEffect(() => {
        if (formStatus.type) {
            const timer = setTimeout(() => {
                setFormStatus({ type: null, message: '' });
            }, 5000);
            return () => clearTimeout(timer);
        }
    }, [formStatus]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        if (!formData.name.trim() || !formData.email.trim() || !formData.message.trim()) {
            setFormStatus({ type: 'error', message: 'Please fill out all fields.' });
            return;
        }

        setIsSending(true);

        // --- IMPORTANT: Replace with your EmailJS credentials ---
        const serviceID = 'YOUR_SERVICE_ID';
        const templateID = 'YOUR_TEMPLATE_ID';
        const publicKey = 'YOUR_PUBLIC_KEY';
        // ---------------------------------------------------------

        const templateParams = {
            from_name: formData.name,
            from_email: formData.email,
            to_name: 'Dr. Mollah',
            message: formData.message,
        };

        window.emailjs.send(serviceID, templateID, templateParams, publicKey)
            .then((response) => {
                console.log('SUCCESS!', response.status, response.text);
                setFormStatus({ type: 'success', message: 'Message sent successfully!' });
                setFormData({ name: '', email: '', message: '' });
            }, (err) => {
                console.log('FAILED...', err);
                setFormStatus({ type: 'error', message: 'Failed to send message. Please try again later.' });
            })
            .finally(() => {
                setIsSending(false);
            });
    };
    
    const inputClasses = "w-full bg-slate-900/50 border border-slate-700 rounded-xl px-5 py-4 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all text-white placeholder-slate-500 font-medium hover:border-slate-600";
    const labelClasses = "block text-sm font-semibold mb-2 text-slate-300 ml-1";

    return (
        <section id="contact" className="relative py-24 px-4">
            <div className="max-w-6xl mx-auto z-10 relative">
                <div className="text-center mb-16">
                    <h2 className="text-3xl md:text-5xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent mb-4">
                        Get In Touch
                    </h2>
                    <p className="text-slate-400 text-lg">
                        We are here to help. Reach out to us via any of the following channels.
                    </p>
                </div>

                <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
                    <div className="bg-slate-800/30 backdrop-blur-sm p-8 rounded-2xl border border-white/5 hover:border-blue-500/30 hover:bg-slate-800/50 transition-all text-center group">
                        <div className="w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                            <Phone className="w-8 h-8 text-blue-400" />
                        </div>
                        <h3 className="font-semibold text-xl text-white mb-2">Phone</h3>
                        <p className="text-slate-400">+91 98765 43210</p>
                        <p className="text-slate-500 text-sm mt-1">Mon-Sat, 9am - 8pm</p>
                    </div>

                    <div className="bg-slate-800/30 backdrop-blur-sm p-8 rounded-2xl border border-white/5 hover:border-blue-500/30 hover:bg-slate-800/50 transition-all text-center group">
                        <div className="w-16 h-16 bg-purple-500/10 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                            <Mail className="w-8 h-8 text-purple-400" />
                        </div>
                        <h3 className="font-semibold text-xl text-white mb-2">Email</h3>
                        <p className="text-slate-400">dr.mollah@healthcare.com</p>
                        <p className="text-slate-500 text-sm mt-1">For general inquiries</p>
                    </div>

                    <div className="bg-slate-800/30 backdrop-blur-sm p-8 rounded-2xl border border-white/5 hover:border-blue-500/30 hover:bg-slate-800/50 transition-all text-center group">
                        <div className="w-16 h-16 bg-cyan-500/10 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                            <MapPin className="w-8 h-8 text-cyan-400" />
                        </div>
                        <h3 className="font-semibold text-xl text-white mb-2">Location</h3>
                        <p className="text-slate-400">Howrah Medical Center</p>
                        <p className="text-slate-500 text-sm mt-1">Howrah, West Bengal, India</p>
                    </div>
                </div>

                <div className="mt-16">
                    <div className="text-center mb-12">
                        <h3 className="text-2xl md:text-3xl font-bold text-white mb-2">
                            Send a Direct Message
                        </h3>
                        <p className="text-slate-400">
                            Have a question? Fill out the form and I'll get back to you.
                        </p>
                    </div>
                    <div className="max-w-2xl mx-auto">
                        <form onSubmit={handleSubmit} className="bg-slate-900/80 backdrop-blur-xl p-8 md:p-10 rounded-3xl border border-blue-500/20 shadow-2xl space-y-6">
                            <div>
                                <label htmlFor="name" className={labelClasses}>Your Name</label>
                                <input type="text" name="name" id="name" value={formData.name} onChange={handleInputChange} className={inputClasses} placeholder="Your full name" />
                            </div>
                            <div>
                                <label htmlFor="email" className={labelClasses}>Your Email</label>
                                <input type="email" name="email" id="email" value={formData.email} onChange={handleInputChange} className={inputClasses} placeholder="your.email@example.com" />
                            </div>
                            <div>
                                <label htmlFor="message" className={labelClasses}>Your Message</label>
                                <textarea name="message" id="message" value={formData.message} onChange={handleInputChange} rows={5} className={`${inputClasses} resize-none`} placeholder="Type your message here..." />
                            </div>

                            <button type="submit" disabled={isSending} className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 text-white py-4 rounded-xl font-bold text-lg hover:from-blue-500 hover:to-cyan-500 transition-all transform hover:scale-[1.01] shadow-lg shadow-blue-500/25 active:scale-95 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed">
                                {isSending ? (
                                    <>
                                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                        </svg>
                                        Sending...
                                    </>
                                ) : (
                                    <>
                                        Send Message <Send className="w-5 h-5" />
                                    </>
                                )}
                            </button>
                        </form>
                         {formStatus.type && (
                            <div className={`mt-6 p-4 rounded-xl flex items-center space-x-3 shadow-lg ${formStatus.type === 'success' ? 'bg-green-500/10 border border-green-500/50 text-green-400' : 'bg-red-500/10 border border-red-500/50 text-red-400'}`}>
                                <div className={`p-2 rounded-full ${formStatus.type === 'success' ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
                                    {formStatus.type === 'success' ? <Check className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
                                </div>
                                <span className="font-medium">{formStatus.message}</span>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </section>
    );
};

export default ContactSection;