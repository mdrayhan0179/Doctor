import React from 'react';
import { Stethoscope } from 'lucide-react';

const Footer: React.FC = () => {
    return (
        <footer className="relative py-10 px-4 border-t border-white/5 bg-slate-950/50">
            <div className="max-w-6xl mx-auto text-center">
                <div className="flex items-center justify-center space-x-2 mb-6">
                    <Stethoscope className="w-6 h-6 text-blue-500" />
                    <span className="text-xl font-bold text-white">Dr. Mollah</span>
                </div>
                <div className="flex justify-center space-x-6 mb-8 text-slate-400">
                    <a href="#/" className="hover:text-blue-400 transition-colors">Privacy Policy</a>
                    <a href="#/" className="hover:text-blue-400 transition-colors">Terms of Service</a>
                    <a href="#/" className="hover:text-blue-400 transition-colors">Patient Portal</a>
                </div>
                <p className="text-slate-500 text-sm">© 2025 Dr. Mohibulla Mollah. All rights reserved. <br /> Designed with care in Howrah.</p>
            </div>
        </footer>
    );
};

export default Footer;
