import React, { useState } from 'react';
import { Stethoscope, Menu, X } from 'lucide-react';
import { NAV_ITEMS } from '../constants';

interface HeaderProps {
    activeSection: string;
    onScrollToSection: (section: string) => void;
}

const Header: React.FC<HeaderProps> = ({ activeSection, onScrollToSection }) => {
    const [menuOpen, setMenuOpen] = useState(false);

    const handleScroll = (section: string) => {
        onScrollToSection(section);
        setMenuOpen(false);
    }

    return (
        <nav className="fixed top-0 w-full bg-slate-900/90 backdrop-blur-md z-50 border-b border-blue-500/20 shadow-lg shadow-blue-900/20 transition-all duration-300">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between items-center h-20">
                    <div className="flex items-center space-x-3 cursor-pointer group" onClick={() => handleScroll('home')}>
                        <div className="bg-blue-500/10 p-2 rounded-lg border border-blue-500/20 group-hover:bg-blue-500/20 transition-colors">
                            <Stethoscope className="w-6 h-6 text-blue-400" />
                        </div>
                        <div className="flex flex-col">
                            <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent tracking-wide">
                                Dr. Mollah
                            </span>
                            <span className="text-[10px] text-slate-400 uppercase tracking-wider font-medium">Internal Medicine</span>
                        </div>
                    </div>

                    <div className="hidden md:flex space-x-1">
                        {NAV_ITEMS.map((item) => (
                            <button
                                key={item}
                                onClick={() => handleScroll(item)}
                                className={`capitalize px-4 py-2 rounded-full transition-all duration-300 text-sm font-medium ${
                                    activeSection === item
                                        ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                                        : 'text-gray-400 hover:text-white hover:bg-white/5'
                                }`}
                            >
                                {item}
                            </button>
                        ))}
                    </div>

                    <button
                        onClick={() => setMenuOpen(!menuOpen)}
                        className="md:hidden p-2 text-gray-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                    >
                        {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                    </button>
                </div>
            </div>

            <div className={`md:hidden absolute w-full bg-slate-900 border-b border-blue-500/20 transition-all duration-300 ease-in-out overflow-hidden ${menuOpen ? 'max-h-96 opacity-100 shadow-2xl' : 'max-h-0 opacity-0'}`}>
                {NAV_ITEMS.map((item) => (
                    <button
                        key={item}
                        onClick={() => handleScroll(item)}
                        className="block w-full text-left px-6 py-4 capitalize text-gray-300 hover:bg-slate-800 hover:text-blue-400 border-l-4 border-transparent hover:border-blue-400 transition-all border-b border-white/5 last:border-0"
                    >
                        {item}
                    </button>
                ))}
            </div>
        </nav>
    );
};

export default Header;
