import React from 'react';
import { ChevronDown, Shield } from 'lucide-react';

interface HeroSectionProps {
    onScrollToSection: (section: string) => void;
}

const HeroSection: React.FC<HeroSectionProps> = ({ onScrollToSection }) => {
    return (
        <section id="home" className="relative min-h-screen flex items-center justify-center px-4 pt-28 pb-12 lg:pt-32">
            <div className="max-w-7xl mx-auto z-10 w-full">
                <div className="grid md:grid-cols-2 gap-12 lg:gap-20 items-center">
                    <div className="text-center md:text-left order-2 md:order-1 animate-fade-in-up">
                        <div className="inline-flex items-center space-x-2 bg-blue-500/10 border border-blue-500/20 rounded-full px-4 py-2 mb-6 backdrop-blur-sm">
                            <span className="relative flex h-3 w-3">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                            </span>
                            <span className="text-sm text-blue-300 font-medium tracking-wide">Accepting New Patients</span>
                        </div>

                        <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6 leading-tight tracking-tight">
                            <span className="block text-slate-100">Expert Consultant in</span>
                            <span className="bg-gradient-to-r from-blue-400 via-cyan-400 to-teal-400 bg-clip-text text-transparent">
                                Internal Medicine
                            </span>
                        </h1>
                        
                        <p className="text-lg md:text-xl text-slate-400 mb-8 max-w-lg mx-auto md:mx-0 leading-relaxed">
                            Trusted by <strong className="text-white">30,000+ patients</strong>. Dr. Mohibulla Mollah provides specialized, evidence-based care for complex medical conditions and chronic disease management.
                        </p>
                        
                        <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                            <button
                                onClick={() => onScrollToSection('appointments')}
                                className="bg-blue-600 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-blue-500 transition-all transform hover:scale-105 shadow-lg shadow-blue-600/25 flex items-center justify-center gap-2 group ring-offset-2 ring-offset-slate-900 focus:ring-2 focus:ring-blue-600"
                            >
                                Book Consultation
                                <ChevronDown className="w-5 h-5 group-hover:translate-y-1 transition-transform" />
                            </button>
                            <button
                                onClick={() => onScrollToSection('services')}
                                className="px-8 py-4 rounded-full text-lg font-semibold text-white border border-white/10 hover:bg-white/5 hover:border-white/20 transition-all flex items-center justify-center gap-2 backdrop-blur-sm"
                            >
                                Clinical Services
                            </button>
                        </div>

                        <div className="mt-12 grid grid-cols-3 gap-8 border-t border-white/10 pt-8">
                            <div className="text-center md:text-left">
                                <div className="text-2xl lg:text-4xl font-bold text-white mb-1">5+</div>
                                <div className="text-xs lg:text-sm text-slate-400 uppercase tracking-wider font-medium">Years Exp.</div>
                            </div>
                            <div className="text-center md:text-left">
                                <div className="text-2xl lg:text-4xl font-bold text-blue-400 mb-1">30k+</div>
                                <div className="text-xs lg:text-sm text-slate-400 uppercase tracking-wider font-medium">Patients Treated</div>
                            </div>
                            <div className="text-center md:text-left">
                                <div className="text-2xl lg:text-4xl font-bold text-white mb-1">4.9</div>
                                <div className="text-xs lg:text-sm text-slate-400 uppercase tracking-wider font-medium">Patient Rating</div>
                            </div>
                        </div>
                    </div>

                    <div className="order-1 md:order-2 flex justify-center relative">
                        <div className="relative w-full max-w-md group">
                            <div className="absolute inset-0 bg-gradient-to-tr from-blue-600 to-cyan-500 rounded-[2rem] blur-3xl opacity-20 group-hover:opacity-30 transition-opacity duration-700"></div>
                            <div className="relative bg-slate-800 rounded-[2rem] p-3 border border-white/10 shadow-2xl overflow-hidden">
                                <div className="aspect-[3/4] overflow-hidden rounded-[1.5rem] relative">
                                    <img
                                        src="https://i.postimg.cc/kGF7bNSt/IMG-20251112-070113.jpg"
                                        alt="Dr. Mohibulla Mollah"
                                        className="w-full h-full object-cover z-10 relative transform transition-transform duration-700 group-hover:scale-105"
                                    />
                                </div>
                                
                                <div className="absolute bottom-6 left-6 right-6 bg-slate-900/90 backdrop-blur-md p-4 rounded-xl border border-white/10 shadow-xl z-20 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-500">
                                    <div className="flex items-center gap-4">
                                        <div className="bg-green-500/20 p-3 rounded-full">
                                            <Shield className="w-6 h-6 text-green-400" />
                                        </div>
                                        <div>
                                            <div className="font-semibold text-white leading-tight">Internal Medicine Specialist</div>
                                            <div className="text-xs text-slate-400 mt-1">Consultant Physician</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default HeroSection;
