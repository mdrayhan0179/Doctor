import React from 'react';
import { SERVICES } from '../constants';

const ServicesSection: React.FC = () => {
    return (
        <section id="services" className="relative py-24 px-4">
            <div className="max-w-7xl mx-auto z-10 relative">
                <div className="text-center mb-16">
                    <h2 className="text-3xl md:text-5xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent mb-4">
                        Clinical Services
                    </h2>
                    <p className="text-slate-400 max-w-2xl mx-auto text-lg">
                        Comprehensive diagnostic and treatment solutions for a wide spectrum of adult health conditions.
                    </p>
                </div>

                <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
                    {SERVICES.map((service, idx) => (
                        <div key={idx} className="group bg-slate-800/40 backdrop-blur-sm p-8 rounded-2xl border border-white/5 hover:bg-slate-800/80 hover:border-blue-500/30 transition-all duration-300 hover:-translate-y-2 shadow-lg hover:shadow-blue-900/20">
                            <div className={`w-14 h-14 ${service.color} bg-white/5 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-inner ring-1 ring-white/5`}>
                                <service.icon className="w-8 h-8" />
                            </div>
                            <h3 className="text-2xl font-semibold mb-3 text-white group-hover:text-blue-400 transition-colors">{service.title}</h3>
                            <p className="text-slate-400 leading-relaxed">{service.desc}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default ServicesSection;
